
#import "CellHoldAction.h"

@interface DeleteAction : CellHoldAction
{
	//
}

@end
