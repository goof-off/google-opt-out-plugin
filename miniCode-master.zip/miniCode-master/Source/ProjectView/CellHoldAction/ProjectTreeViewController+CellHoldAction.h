
#import "../ProjectTreeViewController.h"
#import "CellHoldAction.h"

@interface ProjectTreeViewController()
@property (nonatomic, assign) CellHoldAction* currentHoldAction;
@end
