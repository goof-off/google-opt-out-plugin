
#import "FileBrowserAction.h"

@interface MoveAction : FileBrowserAction
{
	//
}

- (id)initWithProjectTreeViewController:(ProjectTreeViewController*)projectTreeViewController;

@end

