
#import "FileBrowserAction.h"

@interface AddFrameworkAction : FileBrowserAction

- (id)initWithProjectTreeViewController:(ProjectTreeViewController *)projectTreeViewController;

@end
