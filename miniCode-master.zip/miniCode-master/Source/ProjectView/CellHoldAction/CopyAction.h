
#import "FileBrowserAction.h"

@interface CopyAction : FileBrowserAction
{
	//
}

- (id)initWithProjectTreeViewController:(ProjectTreeViewController*)projectTreeViewController;

@end

