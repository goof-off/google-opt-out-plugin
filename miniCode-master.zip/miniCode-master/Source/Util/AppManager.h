
#pragma once

bool AppManager_install(const char* src, const char* appName);
bool AppManager_uninstall(const char* src);
bool AppManager_clean();
bool AppManager_createDefaultFolders();
