
#ifdef __IPHONE_6_1
#define UITextAlignmentCenter NSTextAlignmentCenter
#define UITextAlignmentLeft   NSTextAlignmentLeft
#define UITextAlignmentRight  NSTextAlignmentRight
#endif
