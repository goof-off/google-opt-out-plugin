
#import <UIKit/UIKit.h>

@interface UIView (Animation)
- (void)setFrame:(CGRect)frame animated:(BOOL)animated;
@end