
#import <UIKit/UIKit.h>

@interface ___PROJECTNAMEASIDENTIFIER___AppDelegate : NSObject <UIApplicationDelegate>
{
	UIWindow *window;
}

@property (nonatomic, retain) UIWindow *window;

@end

