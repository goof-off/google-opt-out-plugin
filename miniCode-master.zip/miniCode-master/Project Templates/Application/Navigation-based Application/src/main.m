
#import <UIKit/UIKit.h>

#import "___PROJECTNAMEASIDENTIFIER___AppDelegate.h"

int main(int argc, char *argv[])
{
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([___PROJECTNAMEASIDENTIFIER___AppDelegate class]));
	[pool release];
	return retVal;
}
