miniCode
========

miniCode is a mobile iOS IDE for writing and compiling code directly on iOS (requires "LLVM+Clang", "iOS Toolchain", "ldid", "libtool", and "Open" from Cydia, and must be installed to the root /Applications directory).
